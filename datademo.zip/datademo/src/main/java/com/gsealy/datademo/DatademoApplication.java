package com.gsealy.datademo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class DatademoApplication {

  @Bean
  public RouteLocator customRoute(RouteLocatorBuilder builder) {
    return builder.routes().route("formdata", fn -> fn
        .path("/post")
        .uri("http://httpbin.org/"))
        .build();
  }

  public static void main(String[] args) {
    SpringApplication.run(DatademoApplication.class, args);
  }
}

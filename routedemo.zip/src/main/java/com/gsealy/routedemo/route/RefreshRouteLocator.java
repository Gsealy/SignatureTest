package com.gsealy.routedemo.route;

import javax.validation.constraints.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.gateway.route.Route;
import org.springframework.cloud.gateway.route.RouteDefinition;
import org.springframework.cloud.gateway.route.RouteDefinitionLocator;
import org.springframework.cloud.gateway.route.RouteDefinitionWriter;
import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Component
public class RefreshRouteLocator implements RouteLocator {

  private RouteLocatorBuilder builder;
  private RouteLocatorBuilder.Builder routesBuilder;
  private Flux<Route> route;

  private RouteDefinitionLocator routeDefinitionLocator;

  private RouteLocator routeLocator;
  @Autowired
  GatewayRoutesRefresher gatewayRoutesRefresher;

  @Autowired
  private RouteDefinitionWriter routeDefinitionWriter;

  @Autowired
  public RefreshRouteLocator(RouteLocatorBuilder builder,
      RouteDefinitionLocator routeDefinitionLocator) {
    this.builder = builder;
    this.routeDefinitionLocator = routeDefinitionLocator;
    clearRoutes();
  }

  public void clearRoutes() {
    routesBuilder = builder.routes();
  }

  /**
   * add Route's
   *
   * @param routeDefinition
   * @return
   */
  @NotNull
  public RefreshRouteLocator addRoute(@NotNull RouteDefinition routeDefinition) {
    routeDefinitionWriter.save(Mono.just(routeDefinition)).subscribe();
    return this;
  }

  /**
   * delete Route's
   *
   * @param id
   * @return
   */
  @NotNull
  public RefreshRouteLocator deleteRoute(@NotNull String id) {
    this.routeDefinitionWriter.delete(Mono.just(id)).subscribe();
    return this;
  }

  /**
   * build route's
   */
  public void buildRoutes() {
    if (routesBuilder != null) {
      this.routeLocator = routesBuilder.build();
      this.route = routeLocator.getRoutes();
    }
    gatewayRoutesRefresher.refreshRoutes();
  }

  @Override
  public Flux<Route> getRoutes() {
    return route;
  }
}

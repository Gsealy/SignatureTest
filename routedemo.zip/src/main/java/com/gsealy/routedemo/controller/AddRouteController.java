package com.gsealy.routedemo.controller;

import com.gsealy.routedemo.route.RefreshRouteLocator;
import java.net.URI;
import java.util.Arrays;
import java.util.HashMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.gateway.handler.predicate.PredicateDefinition;
import org.springframework.cloud.gateway.route.RouteDefinition;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/route")
public class AddRouteController {

  @Autowired
  private RefreshRouteLocator refreshRouteLocator;

  @PostMapping("/create")
  private Mono<ResponseEntity<Object>> addNewRoute() {
    RouteDefinition routeDefinition = new RouteDefinition();
    routeDefinition.setUri(URI.create("http://httpbin.org"));

    PredicateDefinition predicateDefinition = new PredicateDefinition();
    predicateDefinition.setName("Path");
    HashMap<String, String> args = new HashMap<>();
    args.put("pattern", "/post");
    args.put("pathPattern", "/post");
    predicateDefinition.setArgs(args);
    routeDefinition.setPredicates(Arrays.asList(predicateDefinition));
    refreshRouteLocator.addRoute(routeDefinition);
    refreshRouteLocator.buildRoutes();
    return Mono.just(ResponseEntity.ok().build());
  }

  @PostMapping("/delete/{id}")
  private Mono<ResponseEntity<Object>> deleRoutes(@PathVariable String id) {
    refreshRouteLocator.deleteRoute(id);
    refreshRouteLocator.buildRoutes();
    return Mono.just(ResponseEntity.ok().build());
  }
}
